<?php
session_start();
require_once '../config/conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // Recibir y limpiar datos del formulario
    $nombre = trim($_POST['nombre']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Array para almacenar errores
    $errores = [];
    
    // VALIDACIONES
    
    // Validar nombre
    if (empty($nombre)) {
        $errores[] = "El nombre es obligatorio";
    } elseif (strlen($nombre) < 3) {
        $errores[] = "El nombre debe tener al menos 3 caracteres";
    }
    
    // Validar email
    if (empty($email)) {
        $errores[] = "El email es obligatorio";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errores[] = "El formato del email no es válido";
    }
    
    // Validar contraseña
    if (empty($password)) {
        $errores[] = "La contraseña es obligatoria";
    } elseif (strlen($password) < 6) {
        $errores[] = "La contraseña debe tener al menos 6 caracteres";
    }
    
    // Validar confirmación de contraseña
    if ($password !== $confirm_password) {
        $errores[] = "Las contraseñas no coinciden";
    }
    
    // Verificar si el email ya existe en la base de datos
    if (empty($errores)) {
        $sql_verificar = "SELECT id FROM usuarios WHERE email = ?";
        $stmt_verificar = $conn->prepare($sql_verificar);
        $stmt_verificar->bind_param("s", $email);
        $stmt_verificar->execute();
        $resultado = $stmt_verificar->get_result();
        
        if ($resultado->num_rows > 0) {
            $errores[] = "El email ya está registrado. Usa otro email o inicia sesión.";
        }
        $stmt_verificar->close();
    }
    
    // Si hay errores, regresar al formulario
    if (!empty($errores)) {
        $_SESSION['errores'] = $errores;
        header("Location: ../views/registro.php");
        exit();
    }
    
    // Si no hay errores, proceder a registrar el usuario
    
    // Encriptar la contraseña
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    
    // Preparar la consulta SQL
    $sql = "INSERT INTO usuarios (nombre, email, password) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $nombre, $email, $password_hash);
    
    // Ejecutar la consulta
    if ($stmt->execute()) {
        $_SESSION['exito'] = "¡Registro exitoso! Ahora puedes iniciar sesión.";
        header("Location: ../views/login.php");
    } else {
        $_SESSION['errores'] = ["Error al registrar el usuario. Intenta de nuevo."];
        header("Location: ../views/registro.php");
    }
    
    $stmt->close();
    $conn->close();
    exit();
    
} else {
    // Si acceden directamente sin POST, redirigir
    header("Location: ../views/registro.php");
    exit();
}
?>