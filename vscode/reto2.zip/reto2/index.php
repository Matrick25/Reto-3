<?php
session_start();

// Si ya está logueado, redirigir al dashboard
if (isset($_SESSION['usuario_id'])) {
    header("Location: views/dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página Principal</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
    <div class="container">
        <div class="welcome-box">
            <h1>Sistema de Gestión de Usuarios</h1>
            <p>Bienvenido a nuestra plataforma</p>
            
            <div class="opciones">
                <a href="views/login.php" class="btn">Iniciar Sesión</a>
                <a href="views/registro.php" class="btn btn-secondary">Registrarse</a>
            </div>
        </div>
    </div>
</body>
</html>