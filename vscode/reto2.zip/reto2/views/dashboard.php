<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit();
}

// Obtener datos del usuario
$nombre = $_SESSION['usuario_nombre'];
$email = $_SESSION['usuario_email'];
$id = $_SESSION['usuario_id'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Usuario</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <div class="container">
        <div class="dashboard">
            <h1>¡Bienvenido, <?php echo htmlspecialchars($nombre); ?>!</h1>
            <p class="subtitulo">Has iniciado sesión correctamente</p>
            
            <div class="info-usuario">
                <h3>Información de tu cuenta</h3>
                <p><strong>ID de usuario:</strong> <?php echo htmlspecialchars($id); ?></p>
                <p><strong>Nombre:</strong> <?php echo htmlspecialchars($nombre); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></p>
            </div>
            
            <div class="acciones">
                <a href="../controllers/logout.php" class="btn btn-logout">Cerrar Sesión</a>
            </div>
        </div>
    </div>
</body>
</html>