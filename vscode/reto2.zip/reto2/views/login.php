<?php
session_start();

// Si ya está logueado, redirigir al dashboard
if (isset($_SESSION['usuario_id'])) {
    header("Location: dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <div class="container">
        <form action="../controllers/procesar_login.php" method="POST" class="form">
            <h2>Iniciar Sesión</h2>
            
            <?php
            // Mostrar errores
            if (isset($_SESSION['error'])) {
                echo '<div class="errores"><p>' . htmlspecialchars($_SESSION['error']) . '</p></div>';
                unset($_SESSION['error']);
            }
            
            // Mostrar mensaje de éxito
            if (isset($_SESSION['exito'])) {
                echo '<div class="exito">' . htmlspecialchars($_SESSION['exito']) . '</div>';
                unset($_SESSION['exito']);
            }
            ?>
            
            <div class="form-group">
                <label for="email">Correo electrónico:</label>
                <input type="email" id="email" name="email" required placeholder="ejemplo@correo.com">
            </div>
            
            <div class="form-group">
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required placeholder="Ingresa tu contraseña">
            </div>
            
            <button type="submit" class="btn">Iniciar Sesión</button>
            
            <p class="texto-centro">
                ¿No tienes cuenta? <a href="registro.php">Regístrate aquí</a>
            </p>
            
            <p class="texto-centro">
                <a href="../index.php">Volver al inicio</a>
            </p>
        </form>
    </div>
</body>
</html>