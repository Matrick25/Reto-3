<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario</title>
    <link rel="stylesheet" href="../css/estilos.css">
</head>
<body>
    <div class="container">
        <form action="../controllers/procesar_registro.php" method="POST" class="form">
            <h2>Crear Cuenta Nueva</h2>
            
            <?php
            // Mostrar errores si existen
            if (isset($_SESSION['errores'])) {
                echo '<div class="errores">';
                foreach ($_SESSION['errores'] as $error) {
                    echo '<p>• ' . htmlspecialchars($error) . '</p>';
                }
                echo '</div>';
                unset($_SESSION['errores']);
            }
            
            // Mostrar mensaje de éxito
            if (isset($_SESSION['exito'])) {
                echo '<div class="exito">' . htmlspecialchars($_SESSION['exito']) . '</div>';
                unset($_SESSION['exito']);
            }
            ?>
            
            <div class="form-group">
                <label for="nombre">Nombre completo:</label>
                <input type="text" id="nombre" name="nombre" required placeholder="Ingresa tu nombre">
            </div>
            
            <div class="form-group">
                <label for="email">Correo electrónico:</label>
                <input type="email" id="email" name="email" required placeholder="ejemplo@correo.com">
            </div>
            
            <div class="form-group">
                <label for="password">Contraseña:</label>
                <input type="password" id="password" name="password" required minlength="6" placeholder="Mínimo 6 caracteres">
                <small>Mínimo 6 caracteres</small>
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Confirmar contraseña:</label>
                <input type="password" id="confirm_password" name="confirm_password" required placeholder="Repite tu contraseña">
            </div>
            
            <button type="submit" class="btn">Registrarse</button>
            
            <p class="texto-centro">
                ¿Ya tienes cuenta? <a href="login.php">Inicia sesión aquí</a>
            </p>
            
            <p class="texto-centro">
                <a href="../index.php">Volver al inicio</a>
            </p>
        </form>
    </div>
</body>
</html>