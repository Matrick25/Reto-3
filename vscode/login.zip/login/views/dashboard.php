<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: ../index.php");
    exit();
}

// Obtener datos del usuario
$nombre = $_SESSION['usuario_nombre'];
$email = $_SESSION['usuario_email'];
$id = $_SESSION['usuario_id'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Usuario</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../css/dashboard.css">
</head>
<body>
    <div class="dashboard-container">
        <div class="dashboard-card">
            <div class="dashboard-header">
                <div class="avatar">
                    <i class="fas fa-user"></i>
                </div>
                <h1>¡Bienvenido, <?php echo htmlspecialchars($nombre); ?>!</h1>
                <p class="subtitle">Has iniciado sesión correctamente</p>
            </div>
            
            <div class="info-card">
                <h2>
                    <i class="fas fa-user-circle"></i>
                    Información de tu cuenta
                </h2>
                <div class="info-item">
                    <span class="info-label"><i class="fas fa-id-badge"></i> ID de usuario:</span>
                    <span class="info-value"><?php echo htmlspecialchars($id); ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label"><i class="fas fa-user"></i> Nombre:</span>
                    <span class="info-value"><?php echo htmlspecialchars($nombre); ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label"><i class="fas fa-envelope"></i> Email:</span>
                    <span class="info-value"><?php echo htmlspecialchars($email); ?></span>
                </div>
            </div>
            
            <div class="dashboard-actions">
                <a href="../controllers/logout.php" class="btn btn-logout">
                    <i class="fas fa-sign-out-alt"></i> Cerrar Sesión
                </a>
            </div>
        </div>
    </div>
</body>
</html>