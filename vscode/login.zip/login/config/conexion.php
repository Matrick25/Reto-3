<?php
// Configuración de la conexión a MySQL
$host = 'localhost';
$dbname = 'gestion_usuarios';
$username = 'root';
$password = '';

// Crear conexión
$conn = new mysqli($host, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Establecer el charset a UTF-8
$conn->set_charset("utf8");
?>