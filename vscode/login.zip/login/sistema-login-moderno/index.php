<?php
session_start();

// Si ya está logueado, redirigir al dashboard
if (isset($_SESSION['usuario_id'])) {
    header("Location: views/dashboard.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Gestión - Login</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>

<body>
    <div class="auth-wrapper" id="authWrapper">
        <!-- FORMULARIO DE REGISTRO -->
        <div class="auth-form-box register-form-box">
            <form action="controllers/procesar_registro.php" method="POST">
                <h1>Crear Cuenta</h1>
                <div class="social-links">
                    <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" aria-label="Google"><i class="fab fa-google"></i></a>
                    <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                </div>
                <span>o usa tu email para registrarte</span>
                
                <?php
                // Mostrar errores si existen
                if (isset($_SESSION['errores'])) {
                    echo '<div class="errores">';
                    foreach ($_SESSION['errores'] as $error) {
                        echo '<p>• ' . htmlspecialchars($error) . '</p>';
                    }
                    echo '</div>';
                    unset($_SESSION['errores']);
                }
                ?>
                
                <input type="text" name="nombre" placeholder="Nombre completo" required />
                <input type="email" name="email" placeholder="Correo Electrónico" required />
                <input type="password" name="password" placeholder="Contraseña (mín. 6 caracteres)" required minlength="6" />
                <input type="password" name="confirm_password" placeholder="Confirmar Contraseña" required />
                <button type="submit">Registrarse</button>
                <div class="mobile-switch">
                    <p>¿Ya tienes cuenta?</p>
                    <button type="button" id="mobileLoginBtn">Iniciar Sesión</button>
                </div>
            </form>
        </div>

        <!-- FORMULARIO DE LOGIN -->
        <div class="auth-form-box login-form-box">
            <form action="controllers/procesar_login.php" method="POST">
                <h1>Iniciar Sesión</h1>
                <div class="social-links">
                    <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" aria-label="Google"><i class="fab fa-google"></i></a>
                    <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                </div>
                <span>o usa tu cuenta</span>
                
                <?php
                // Mostrar error de login
                if (isset($_SESSION['error'])) {
                    echo '<div class="errores"><p>' . htmlspecialchars($_SESSION['error']) . '</p></div>';
                    unset($_SESSION['error']);
                }
                
                // Mostrar mensaje de éxito
                if (isset($_SESSION['exito'])) {
                    echo '<div class="exito">' . htmlspecialchars($_SESSION['exito']) . '</div>';
                    unset($_SESSION['exito']);
                }
                ?>
                
                <input type="email" name="email" placeholder="Correo Electrónico" required />
                <input type="password" name="password" placeholder="Contraseña" required />
                <a href="#">¿Olvidaste tu contraseña?</a>
                <button type="submit">Iniciar Sesión</button>
                <div class="mobile-switch">
                    <p>¿No tienes cuenta?</p>
                    <button type="button" id="mobileRegisterBtn">Registrarse</button>
                </div>
            </form>
        </div>

        <!-- PANEL DESLIZANTE -->
        <div class="slide-panel-wrapper">
            <div class="slide-panel">
                <div class="panel-content panel-content-left">
                    <h1>¡Hola de Nuevo!</h1>
                    <p>Inicia sesión con tus credenciales y continúa tu experiencia.</p>
                    <button class="transparent-btn" id="loginBtn">Iniciar Sesión</button>
                </div>
                <div class="panel-content panel-content-right">
                    <h1>¡Bienvenido!</h1>
                    <p>Comienza tu increíble viaje creando una cuenta con nosotros hoy</p>
                    <button class="transparent-btn" id="registerBtn">Registrarse</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        const registerBtn = document.getElementById('registerBtn');
        const loginBtn = document.getElementById('loginBtn');
        const mobileRegisterBtn = document.getElementById('mobileRegisterBtn');
        const mobileLoginBtn = document.getElementById('mobileLoginBtn');
        const authWrapper = document.getElementById('authWrapper');

        if (registerBtn) {
            registerBtn.addEventListener('click', () => {
                authWrapper.classList.add("panel-active");
            });
        }

        if (loginBtn) {
            loginBtn.addEventListener('click', () => {
                authWrapper.classList.remove("panel-active");
            });
        }

        if (mobileRegisterBtn) {
            mobileRegisterBtn.addEventListener('click', () => {
                authWrapper.classList.add("panel-active");
            });
        }

        if (mobileLoginBtn) {
            mobileLoginBtn.addEventListener('click', () => {
                authWrapper.classList.remove("panel-active");
            });
        }
    </script>
</body>
</html>
