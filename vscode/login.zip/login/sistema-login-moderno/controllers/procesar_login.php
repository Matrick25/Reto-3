<?php
session_start();
require_once '../config/conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // Recibir datos del formulario
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    // Validar que los campos no estén vacíos
    if (empty($email) || empty($password)) {
        $_SESSION['error'] = "Todos los campos son obligatorios";
        header("Location: ../index.php");
        exit();
    }
    
    // Buscar el usuario en la base de datos
    $sql = "SELECT id, nombre, email, password FROM usuarios WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $resultado = $stmt->get_result();
    
    // Verificar si el usuario existe
    if ($resultado->num_rows === 1) {
        $usuario = $resultado->fetch_assoc();
        
        // Verificar la contraseña
        if (password_verify($password, $usuario['password'])) {
            // Contraseña correcta - Crear sesión
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['usuario_nombre'] = $usuario['nombre'];
            $_SESSION['usuario_email'] = $usuario['email'];
            
            // Redirigir al dashboard
            header("Location: ../views/dashboard.php");
            exit();
        } else {
            // Contraseña incorrecta
            $_SESSION['error'] = "Contraseña incorrecta";
        }
    } else {
        // Usuario no existe
        $_SESSION['error'] = "El usuario no existe. Verifica tu email.";
    }
    
    $stmt->close();
    $conn->close();
    
    // Si llegó aquí, hubo un error
    header("Location: ../index.php");
    exit();
    
} else {
    // Si acceden directamente sin POST
    header("Location: ../index.php");
    exit();
}
?>
