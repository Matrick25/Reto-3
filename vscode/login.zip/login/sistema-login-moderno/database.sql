-- Base de datos para el Sistema de Gestión de Usuarios
-- Ejecuta este script en tu MySQL/phpMyAdmin

CREATE DATABASE IF NOT EXISTS gestion_usuarios;

USE gestion_usuarios;

CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Mensaje de confirmación
SELECT 'Base de datos y tabla creadas exitosamente' AS Mensaje;
