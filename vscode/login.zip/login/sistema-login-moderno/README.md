# Sistema de Gestión de Usuarios - Diseño Modernizado

Este es tu sistema de login/registro con un diseño moderno y animado.

## 📁 Estructura de Archivos

```
proyecto/
├── index.php                    (Página principal con login/registro)
├── css/
│   ├── style.css               (Estilos del login/registro)
│   └── dashboard.css           (Estilos del dashboard)
├── views/
│   └── dashboard.php           (Panel de usuario)
├── controllers/
│   ├── procesar_login.php      (Procesamiento del login)
│   ├── procesar_registro.php   (Procesamiento del registro)
│   └── logout.php              (Cierre de sesión)
└── config/
    └── conexion.php            (Conexión a la base de datos)
```

## 🚀 Instalación

### 1. Configurar la Base de Datos

Crea una base de datos llamada `gestion_usuarios` y ejecuta este SQL:

```sql
CREATE DATABASE gestion_usuarios;

USE gestion_usuarios;

CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### 2. Configurar la Conexión

Edita el archivo `config/conexion.php` con tus credenciales:

```php
$host = 'localhost';
$dbname = 'gestion_usuarios';
$username = 'root';        // Tu usuario de MySQL
$password = '';            // Tu contraseña de MySQL
```

### 3. Organizar los Archivos

Coloca los archivos en tu servidor según esta estructura:

- `index.php` → En la raíz de tu proyecto
- `style.css` → En la carpeta `css/`
- `dashboard.css` → En la carpeta `css/`
- `dashboard.php` → En la carpeta `views/`
- `procesar_login.php`, `procesar_registro.php`, `logout.php` → En la carpeta `controllers/`
- `conexion.php` → En la carpeta `config/`

## ✨ Características

### Diseño Moderno
- Animaciones fluidas entre login y registro
- Panel deslizante con degradados morados
- Diseño responsive (mobile-friendly)
- Iconos de Font Awesome

### Funcionalidad
- Registro de usuarios con validación
- Login seguro con contraseñas encriptadas
- Sesiones de usuario
- Mensajes de error y éxito integrados
- Dashboard personalizado

### Validaciones Incluidas
- Email válido
- Contraseña mínimo 6 caracteres
- Verificación de contraseñas coincidentes
- Email único (no duplicados)

## 🎨 Personalización

### Cambiar los Colores

En `style.css` y `dashboard.css`, puedes modificar:

```css
/* Color de fondo principal */
background: #001675;

/* Gradiente del botón y panel */
background: linear-gradient(135deg, #c581ff 0%, #764ba2 100%);
```

### Modificar los Textos

En `index.php`, puedes cambiar los textos del panel deslizante:

```php
<h1>¡Hola de Nuevo!</h1>
<p>Inicia sesión con tus credenciales...</p>
```

## 🔒 Seguridad

- Las contraseñas se encriptan con `password_hash()`
- Validación en el servidor (PHP)
- Protección contra SQL injection con prepared statements
- Sesiones seguras

## 📱 Responsive

El diseño se adapta automáticamente a:
- Desktop (850px+)
- Tablet (768px - 850px)
- Mobile (<768px)

En mobile, el panel deslizante se oculta y aparecen botones para cambiar entre login y registro.

## 🛠️ Solución de Problemas

### "Error de conexión a la base de datos"
- Verifica que MySQL esté corriendo
- Comprueba las credenciales en `conexion.php`
- Asegúrate de que la base de datos existe

### "El email ya está registrado"
- El email debe ser único
- Usa otro email o inicia sesión

### Los estilos no se cargan
- Verifica que la carpeta `css/` exista
- Comprueba las rutas en los archivos PHP
- Asegúrate de que Font Awesome esté disponible

## 📄 Licencia

Este proyecto está diseñado para uso personal y educativo.
