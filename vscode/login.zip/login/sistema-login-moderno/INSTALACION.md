# 📋 GUÍA DE INSTALACIÓN RÁPIDA

## 🎯 Paso 1: Preparar el Servidor

1. Asegúrate de tener instalado:
   - XAMPP, WAMP, MAMP o similar
   - PHP 7.4 o superior
   - MySQL 5.7 o superior

2. Inicia Apache y MySQL

## 🗄️ Paso 2: Crear la Base de Datos

### Opción A: Usando phpMyAdmin
1. Abre http://localhost/phpmyadmin
2. Ve a la pestaña "SQL"
3. Copia y pega el contenido de `database.sql`
4. Haz clic en "Continuar"

### Opción B: Usando línea de comandos
```bash
mysql -u root -p < database.sql
```

## 📁 Paso 3: Organizar los Archivos

Copia todos los archivos a tu servidor según esta estructura:

```
htdocs/mi_proyecto/
│
├── index.php                    ← Archivo principal
├── database.sql                 ← Script SQL
├── README.md                    ← Documentación
│
├── css/
│   ├── style.css               ← Estilos login/registro
│   └── dashboard.css           ← Estilos dashboard
│
├── views/
│   └── dashboard.php           ← Panel de usuario
│
├── controllers/
│   ├── procesar_login.php      ← Procesa login
│   ├── procesar_registro.php   ← Procesa registro
│   └── logout.php              ← Cierra sesión
│
└── config/
    └── conexion.php            ← Configuración BD
```

## ⚙️ Paso 4: Configurar la Conexión

Edita `config/conexion.php`:

```php
$host = 'localhost';
$dbname = 'gestion_usuarios';
$username = 'root';              // Cambia si es diferente
$password = '';                  // Agrega tu contraseña si tienes
```

## 🚀 Paso 5: ¡Probar!

1. Abre tu navegador
2. Ve a: `http://localhost/mi_proyecto`
3. ¡Deberías ver el formulario de login/registro!

## ✅ Verificación

### El sistema está funcionando si:
- ✅ Ves el formulario animado con diseño morado
- ✅ Puedes cambiar entre "Iniciar Sesión" y "Registrarse"
- ✅ El formulario es responsive (se adapta al móvil)

### Problemas comunes:

#### "Error de conexión"
- Verifica que MySQL esté corriendo
- Revisa las credenciales en `conexion.php`
- Asegúrate de que la BD existe

#### "No se cargan los estilos"
- Verifica que la carpeta `css/` exista
- Comprueba las rutas en los archivos
- Revisa la consola del navegador (F12)

#### "Call to undefined function mysqli_connect()"
- Activa la extensión mysqli en php.ini
- Reinicia Apache

## 🎨 Características del Diseño

### Login/Registro
- ✨ Animación suave entre formularios
- 🎨 Panel deslizante con degradado morado
- 📱 100% responsive
- 🔒 Integración de redes sociales (opcional)
- ✅ Mensajes de error/éxito integrados

### Dashboard
- 👤 Avatar personalizado con icono
- 📊 Tarjeta de información del usuario
- 🎨 Diseño limpio y moderno
- 🚪 Botón de cerrar sesión destacado

## 🔐 Seguridad Implementada

- ✅ Contraseñas encriptadas (password_hash)
- ✅ Prepared statements (anti SQL injection)
- ✅ Validación de email
- ✅ Sesiones seguras
- ✅ Limpieza de datos (trim)
- ✅ Validación de longitud de contraseña

## 📱 Responsive Design

El sistema se adapta a:
- 💻 Desktop (850px+)
- 📱 Tablet (768px - 850px)
- 📱 Mobile (<768px)

En móvil, el panel deslizante se oculta y aparecen botones para alternar entre formularios.

## 🎯 Próximos Pasos

Una vez funcionando, puedes:
1. Personalizar los colores en los archivos CSS
2. Agregar más campos al formulario de registro
3. Implementar "recuperar contraseña"
4. Agregar más páginas al dashboard
5. Integrar autenticación con redes sociales

## 🆘 Soporte

Si tienes problemas:
1. Verifica los logs de error de Apache
2. Revisa la consola del navegador (F12)
3. Comprueba los permisos de archivos
4. Asegúrate de que todas las carpetas existan

## 📞 Contacto

¿Necesitas ayuda? Revisa el archivo README.md para más detalles técnicos.

---

¡Disfruta tu nuevo sistema de login! 🎉
